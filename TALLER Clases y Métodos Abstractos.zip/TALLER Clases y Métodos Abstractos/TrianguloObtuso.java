
package paquete1;
//camilo

public class TrianguloObtuso extends Triangulo {
    //atributos
    private double base;
    private double altura;
    //metodo set
    public void setBase(double base) {
        this.base = base;
    }
    //metodo get
    public double getBase() {
        return base;
    }

    //metodo set
    public void setAltura(double altura) {
        this.altura = altura;
    }
    //metodo get
    public double getAltura() {
        return altura;
    }
     @Override    
      public void calculararea(){
      
          //operacion para calcular el area
          double area = (base * altura) / 2;
          //muestro el siguiente mensaje en la consola
           System.out.println("El area del triangulo obtuso es: " + area);  
               
    }
   
}
