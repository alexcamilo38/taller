
package paquete1;
//camilo

public class Triangulo extends FiguraGeometrica {
    
    
   @Override    
      public void calculararea(){
          //muestro el siguiente mensaje en la consola
          System.out.println("el area de los siguientes triangolos es: "); 
      }  
    
}
