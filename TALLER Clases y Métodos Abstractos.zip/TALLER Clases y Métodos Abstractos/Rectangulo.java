
package paquete1;
//camilo

public class Rectangulo extends FiguraGeometrica{
    //atrivulos
    private double base;
    private double altura;
    
    
    public void setBase(double base) {
        this.base = base;
    }
    public double getBase() {
        return base;
    }

   
    public void setAltura(double altura) {
        this.altura = altura;
    }
    public double getAltura() {
        return altura;
    }

     
    @Override    
      public void calculararea(){
         double area = base * altura;
         //muestro el siguiente mensaje en  la consola
         System.out.println("El area de el rectangulo es: " +area);
      }
}
