

package paquete1;
//camilo

public class TrianguloEquilatero extends Triangulo {
    //atributo
    private double lado;
    
    
     public void setLado(double lado) {
        this.lado = lado;
    }
     
    public double getLado() {
        return lado;
    }

   
  
    @Override    
      public void calculararea(){
         
          double area = (Math.sqrt(3) / 4) *lado * lado;
          //muestro el siguiente mensaje en la consola
          System.out.println("el area del triangolos Equilatero es: " +area); 
      }  
    
}
