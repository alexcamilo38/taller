
package paquete1;
//camilo

public abstract class FiguraGeometrica {
    
      public abstract  void calculararea();   
}
