
package paquete1;
//camilo

public class Main {
    public static void main(String[] args) {
     // Círculo (diámetro o radio)
        Circulo circulo = new Circulo();
        circulo.setDiametro(10);
        circulo.calcularRadio();
        circulo.calculararea();

        // Rectángulo
        Rectangulo rectangulo = new Rectangulo();
        rectangulo.setBase(5);
        rectangulo.setAltura(8);
        rectangulo.calculararea();

        // Triángulo Equilátero
        TrianguloEquilatero te = new TrianguloEquilatero();
        te.setLado(6);
        te.calculararea();

        // Triángulo Isósceles
        TrianguloIsosceles ti = new TrianguloIsosceles();
        ti.setLadosIguales(5);
        ti.setBase(6);
        ti.calculararea();

        // Triángulo Obtuso (base y altura)
        TrianguloObtuso to = new TrianguloObtuso();
        to.setBase(8);
        to.setAltura(5);
        to.calculararea();
    }  
}
