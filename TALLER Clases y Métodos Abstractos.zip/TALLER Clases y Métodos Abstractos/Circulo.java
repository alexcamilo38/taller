
package paquete1;


public class Circulo extends FiguraGeometrica{
    private double diametro;
    private double radio;
    
    public void setDiametro(double diametro) {
        this.diametro = diametro;
    }

    public double getDiametro() {
        return diametro;
    }
    
    
    public void setRadio(double radio) {
        this.radio = radio;
    }
    public double getRadio() {
        return radio;
    }
    
     public void calcularRadio() {
        if(diametro > 0){
            radio = diametro / 2;
        }
    }
   
    @Override
     
      public void calculararea(){
        double area = Math.PI * radio * radio;
        //muestro el siguiente mensaje en consola
        System.out.println("El area de el circulo es: "+area);
    }
}
