
package paquete1;


public class TrianguloIsosceles extends Triangulo{
    //atributos
    private double ladosIguales;
    private double base;
    //metodo set
    public void setLadosIguales(double ladosIguales) {
        this.ladosIguales = ladosIguales;
    }
    //metodo get
    public double getLadosIguales() {
        return ladosIguales;
    }

    
    //metodo set
     public void setBase(double base) {
        this.base = base;
    }
     //metodo get
    public double getBase() {
        return base;
    }

    @Override    
      public void calculararea(){
          double altura = Math.sqrt((ladosIguales * ladosIguales) - (base * base / 4));
          //operacion
          double area = (base * altura) / 2;
          //muestro el siguiente mensaje en la consola
          System.out.println("El area del triangulo isosceles es: " + area);
    }   
}
