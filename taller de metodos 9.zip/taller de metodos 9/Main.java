
package paquete1;
//camilo


//llamamos a clase principal
public class Main {
    //invoco a a la clase invocoa la clase prinpal main
    public static void main(String[] args) {
        //informacion de el carro
        Carro carro = new Carro();
        carro.setMarca("Mazda");
        carro.setAño(2000);
        carro.setModelo("34");
        carro.setCilindraje(2000);
        carro.calcularMantenimiento();
        
        //informacion de la moto
        Moto moto= new Moto();
        moto.setMarca("Honda");
        moto.setAño(2024);
        moto.setModelo("XR");
        moto.setCilindraje(190);
        moto.calcularMantenimiento();
        
        //informacion de el bus
        Bus bus = new Bus();
        bus.setMarca("Chevrolet");
        bus.setAño(2020);
        bus.setModelo("BYD");
        bus.setCilindraje(5000);
        bus.calcularMantenimiento();
        
        
    }
    
}
