
package paquete1;
//camilo

public class Bus extends VehiculoMotorizado {

    @Override
    public void calcularMantenimiento() {
        //muestro el siguiente mensaje en la consola
        System.out.println("El mantenimiento del Bus es aproximadamente $950.000 mensuales");
    }      
    
}
