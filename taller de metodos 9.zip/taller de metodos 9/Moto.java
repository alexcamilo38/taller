
package paquete1;
//camilo

public class Moto extends VehiculoMotorizado {

    @Override
    public void calcularMantenimiento() {
        //muestro el siguiente mensaje en la consola
        System.out.println("El mantenimiento del Moto es aproximadamente $150.000 mensuales");
    }
    
    
}
