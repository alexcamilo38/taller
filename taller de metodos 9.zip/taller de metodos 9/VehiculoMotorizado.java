
package paquete1;
//camilo

public abstract class VehiculoMotorizado extends Vehiculo {
    //atributo
    private int cilindraje;
    
    //metodo set
    public void setCilindraje(int cilindraje) {
        this.cilindraje = cilindraje;
    }
    //metodo get
    public int getCilindraje() {
        return cilindraje;
    }

  
}
