
package paquete1;
//camilo

public class Carro extends VehiculoMotorizado{
    
    @Override
    public  void calcularMantenimiento() {
        //muestro el siguiente mensaje en la consola
        System.out.println("El mantenimiento del carro es aproximadamente $400.000 mensuales");             
  }  
}
