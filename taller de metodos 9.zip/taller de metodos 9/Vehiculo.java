
package paquete1;
//camilo

public abstract class Vehiculo {
    //atributos
    private String marca;
    private String modelo;
    private int año;
    //metodo set
     public void setAño(int año) {
        this.año = año;
    }
     //metodo get
    public int getAño() {
        return año;
    }
    //metodo set
    public void setMarca(String marca) {
        this.marca = marca;
    }
    //metodo get
    public String getMarca() {
        return marca;
    }
    //metodo set
    public void setModelo(String modelo) {
        this.modelo = modelo;
    }
    //metodo get
    public String getModelo() {
        return modelo;
    }  
      public abstract  void calcularMantenimiento();
         
}
